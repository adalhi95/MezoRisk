# Mezo Risk Alerts — Vercel deploy

Static dashboard + serverless API + **hourly/minute cron** that indexes real `AssetsUnlocked` bridge-out events on Mezo and emails you when thresholds are hit.

## Deploy

1. Push this folder to GitHub (or `vercel deploy` from the folder).
2. In Vercel project → **Settings → Environment Variables** set:

| Variable | Required | Notes |
|----------|----------|--------|
| `UPSTASH_REDIS_REST_URL` | **Yes** for persistence | Free at [upstash.com](https://upstash.com) → Redis → REST |
| `UPSTASH_REDIS_REST_TOKEN` | **Yes** | |
| `RESEND_API_KEY` | For real email | Free at [resend.com](https://resend.com) |
| `RESEND_FROM` | Optional | Default `onboarding@resend.dev` |
| `CRON_SECRET` | Recommended | Random string; Cron Jobs use it |
| `MEZO_RPCS` | Optional | Comma-separated RPC URLs |

3. Deploy. Vercel Cron calls `/api/cron/poll` every minute (`vercel.json`).

**Hobby plan:** Cron minimum is once per day on free Hobby in some accounts — if so, change schedule or upgrade, or hit `/api/cron/poll` from an external cron (cron-job.org).


## Vercel Hobby note

On **Hobby**, Vercel Cron may only run **once per day**. For near-real-time alerts:

1. Deploy this project as usual.
2. Create a free job at [cron-job.org](https://cron-job.org) (or similar):
   - URL: `https://YOUR_PROJECT.vercel.app/api/cron/poll`
   - Schedule: every 1–5 minutes
   - Header (if you set `CRON_SECRET`): `Authorization: Bearer YOUR_SECRET`

The same endpoint powers Vercel’s built-in cron, so both can call it safely.

## Local test

```bash
# no build step — use vercel dev
npx vercel dev
```

Open the URL shown, sign in with any email, add a bridge alert.

## Files you need (this folder)

```
vercel-mezo-alerts/
  vercel.json          # static public/ + cron
  package.json
  .env.example
  public/index.html    # dashboard
  api/
    auth/login.js
    alerts/index.js
    alerts/[id].js
    triggers.js
    outflows.js
    health.js
    cron/poll.js       # indexes chain + sends email
  lib/
    db.js              # Upstash Redis
    mezo.js            # AssetsUnlocked logs
    email.js           # Resend
    http.js
```

## How alerts work

1. User signs in → `POST /api/auth/login`
2. User creates alert → stored in Redis
3. Cron runs → `eth_getLogs` on AssetsBridge `0x7b7c…0012` for `AssetsUnlocked`
4. BTC outflows summed over each alert’s window → if over threshold, email via Resend
