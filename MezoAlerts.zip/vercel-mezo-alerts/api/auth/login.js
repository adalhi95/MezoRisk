const db = require("../../lib/db");
const { cors, json } = require("../../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return json(res, 405, { error: "Method not allowed" });

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body || {};
    const email = String(body.email || "").trim().toLowerCase();
    if (!email || !email.includes("@")) return json(res, 400, { error: "Valid email required" });

    const name = body.name || email.split("@")[0];
    const picture = body.picture || null;
    const provider = body.provider || "demo";

    let user = await db.getUserByEmail(email);
    if (!user) {
      user = await db.upsertUser({
        id: db.uuid(),
        email,
        name,
        picture,
        provider,
        created_at: new Date().toISOString(),
      });
    } else {
      user = await db.upsertUser({
        ...user,
        name,
        picture: picture || user.picture,
        provider,
      });
    }

    return json(res, 200, {
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        picture: user.picture,
        provider: user.provider,
      },
      token: user.id,
    });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};
