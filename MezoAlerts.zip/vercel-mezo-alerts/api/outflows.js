const db = require("../lib/db");
const { cors, json } = require("../lib/http");
const { syncRecent } = require("../lib/worker");

async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET") return json(res, 405, { error: "Method not allowed" });

  try {
    // Index new bridge events before returning — this is why the dashboard stays live
    let sync = null;
    try {
      sync = await syncRecent();
    } catch (e) {
      console.warn("[outflows] syncRecent failed:", e.message);
      sync = { error: e.message };
    }

    const minutes = Math.min(Number(req.query.minutes) || 60, 24 * 60);
    const { rows, totalBtc, totalUsdc } = await db.listOutflows(minutes);
    return json(res, 200, {
      minutes,
      totalBtc: totalBtc || 0,
      totalUsdc: totalUsdc || 0,
      outflows: rows,
      sync,
    });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};

module.exports = handler;
module.exports.config = { maxDuration: 30 };
