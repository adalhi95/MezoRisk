const { pollOnce } = require("../lib/worker");
const { cors, json } = require("../lib/http");

async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET" && req.method !== "POST") {
    return json(res, 405, { error: "Method not allowed" });
  }

  try {
    const result = await pollOnce({ lookback: 80, maxBlocks: 500 });
    return json(res, 200, { ok: true, ...result, time: new Date().toISOString() });
  } catch (e) {
    console.error("[sync]", e);
    return json(res, 500, { error: e.message });
  }
};

module.exports = handler;
module.exports.config = { maxDuration: 30 };
