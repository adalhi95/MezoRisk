/**
 * Vercel Cron + external cron-job.org target.
 */
const { pollOnce } = require("../../lib/worker");
const { json } = require("../../lib/http");

async function handler(req, res) {
  if (req.method !== "GET" && req.method !== "POST") {
    return json(res, 405, { error: "Method not allowed" });
  }

  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.authorization || "";
    if (auth !== `Bearer ${secret}`) {
      return json(res, 401, { error: "Unauthorized" });
    }
  }

  try {
    // Full catch-up for cron (more blocks than dashboard sync)
    const result = await pollOnce({ lookback: 100, maxBlocks: 800 });
    return json(res, 200, { ok: true, ...result, time: new Date().toISOString() });
  } catch (e) {
    console.error("[cron]", e);
    return json(res, 500, { error: e.message });
  }
};

module.exports = handler;
module.exports.config = { maxDuration: 30 };
