const db = require("../lib/db");
const { cors, json } = require("../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  try {
    const stats = await db.stats();
    return json(res, 200, {
      ok: true,
      lastIndexedBlock: stats.lastIndexedBlock,
      activeAlerts: stats.activeAlerts,
      storage: stats.storage,
      time: new Date().toISOString(),
    });
  } catch (e) {
    return json(res, 500, { error: e.message });
  }
};
