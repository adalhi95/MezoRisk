const db = require("../../lib/db");
const { cors, json, userFromReq } = require("../../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "DELETE") return json(res, 405, { error: "Method not allowed" });

  try {
    const user = await userFromReq(req, db);
    if (!user) return json(res, 401, { error: "Sign in required" });

    const id = req.query.id;
    const ok = await db.deleteAlert(id, user.id);
    if (!ok) return json(res, 404, { error: "Not found" });
    return json(res, 200, { ok: true });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};
