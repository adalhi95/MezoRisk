const db = require("../../lib/db");
const { cors, json, userFromReq } = require("../../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();

  try {
    const user = await userFromReq(req, db);
    if (!user) return json(res, 401, { error: "Sign in required" });

    if (req.method === "GET") {
      const alerts = await db.listAlerts(user.id);
      return json(res, 200, { alerts });
    }

    if (req.method === "POST") {
      const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body || {};
      const asset = String(body.asset || "btc").toLowerCase();
      if (asset !== "btc" && asset !== "usdc") {
        return json(res, 400, { error: "asset must be btc or usdc" });
      }
      const threshold = Number(
        body.threshold ?? body.thresholdBtc ?? body.threshold_btc ?? body.thresholdUsdc
      );
      const windowMinutes = Number(
        body.windowMinutes ?? body.window_minutes
      );
      const unit = asset === "usdc" ? "USDC" : "BTC";
      const label =
        String(body.label || "").trim() ||
        `≥ ${threshold} ${unit} / ${windowMinutes}m`;

      if (!(threshold > 0) || !(windowMinutes >= 1)) {
        return json(res, 400, { error: "Invalid threshold or window" });
      }

      const alert = await db.addAlert({
        id: db.uuid(),
        user_id: user.id,
        email: user.email,
        label,
        asset,
        threshold,
        threshold_btc: asset === "btc" ? threshold : 0,
        window_minutes: windowMinutes,
        status: "active",
        created_at: new Date().toISOString(),
        last_triggered_at: null,
      });
      return json(res, 201, { alert });
    }

    return json(res, 405, { error: "Method not allowed" });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};
