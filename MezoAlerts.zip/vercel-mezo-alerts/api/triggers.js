const db = require("../lib/db");
const { cors, json, userFromReq } = require("../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET") return json(res, 405, { error: "Method not allowed" });

  try {
    const user = await userFromReq(req, db);
    if (!user) return json(res, 401, { error: "Sign in required" });
    const triggers = await db.listTriggers(user.id);
    return json(res, 200, { triggers });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};
