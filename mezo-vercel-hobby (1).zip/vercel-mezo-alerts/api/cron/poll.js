/**
 * Vercel Cron — runs every minute (see vercel.json).
 * Indexes AssetsUnlocked events and evaluates alerts.
 */
const db = require("../../lib/db");
const { getLatestBlock, fetchAssetsUnlocked } = require("../../lib/mezo");
const { sendAlertEmail } = require("../../lib/email");
const { json } = require("../../lib/http");

const LOOKBACK = 80;
const CHUNK = 400;

async function evaluateAlerts() {
  const alerts = await db.activeAlerts();
  for (const a of alerts) {
    const { total, count } = await db.sumOutflowBtc(a.window_minutes);
    if (total < a.threshold_btc) continue;

    if (a.last_triggered_at) {
      const last = new Date(a.last_triggered_at).getTime();
      if (Date.now() - last < a.window_minutes * 60 * 1000) continue;
    }

    const now = new Date().toISOString();
    await db.touchAlert(a.id, now);

    const triggerId = db.uuid();
    await db.addTrigger({
      id: triggerId,
      alert_id: a.id,
      email: a.email,
      label: a.label,
      threshold_btc: a.threshold_btc,
      window_minutes: a.window_minutes,
      outflow_btc: total,
      event_count: count,
      at: now,
      email_status: "pending",
    });

    const subject = `[Mezo Alert] Bridge outflow ≥ ${a.threshold_btc} BTC (${a.label})`;
    const text = [
      `Mezo Bridge Outflow Alert`,
      ``,
      `Label: ${a.label}`,
      `Threshold: ${a.threshold_btc} BTC in ${a.window_minutes} minutes`,
      `Observed outflow: ${total.toFixed(6)} BTC across ${count} AssetsUnlocked event(s)`,
      `Time (UTC): ${now}`,
      ``,
      `Source: AssetsUnlocked on Mezo AssetsBridge 0x7b7c…0012`,
    ].join("\n");

    try {
      const result = await sendAlertEmail({
        to: a.email,
        subject,
        text,
        html: `<pre>${text.replace(/</g, "&lt;")}</pre>`,
      });
      await db.updateTriggerStatus(triggerId, `sent:${result.method}`);
      console.log(`[alert] ${a.label} → ${a.email} via ${result.method}`);
    } catch (e) {
      await db.updateTriggerStatus(triggerId, `error:${e.message}`);
      console.error("[alert] email failed", e.message);
    }
  }
}

async function pollOnce() {
  const latest = await getLatestBlock();
  let from = Number(await db.getMeta("last_block", "0"));
  if (!from || from <= 0) {
    from = Math.max(0, latest - LOOKBACK);
  } else {
    from = from + 1;
  }
  if (from > latest) return { latest, inserted: 0 };

  let inserted = 0;
  let cursor = from;
  while (cursor <= latest) {
    const to = Math.min(cursor + CHUNK - 1, latest);
    const events = await fetchAssetsUnlocked(cursor, to);
    for (const e of events) {
      const row = {
        id: db.uuid(),
        sequence_number: e.sequenceNumber,
        token: e.token,
        sender: e.sender,
        amount_wei: e.amountWei,
        amount_btc: e.amountBtc,
        chain: e.chain,
        block_number: e.blockNumber,
        tx_hash: e.txHash,
        log_index: e.logIndex,
        at: new Date().toISOString(),
      };
      if (await db.insertOutflow(row)) inserted++;
    }
    await db.setMeta("last_block", String(to));
    cursor = to + 1;
  }

  await evaluateAlerts();
  return { latest, inserted };
}

module.exports = async function handler(req, res) {
  // Vercel Cron sends GET; also allow manual POST
  if (req.method !== "GET" && req.method !== "POST") {
    return json(res, 405, { error: "Method not allowed" });
  }

  // Optional shared secret
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.authorization || "";
    if (auth !== `Bearer ${secret}`) {
      return json(res, 401, { error: "Unauthorized" });
    }
  }

  try {
    const result = await pollOnce();
    return json(res, 200, { ok: true, ...result, time: new Date().toISOString() });
  } catch (e) {
    console.error("[cron]", e);
    return json(res, 500, { error: e.message });
  }
};
