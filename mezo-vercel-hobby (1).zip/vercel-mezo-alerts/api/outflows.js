const db = require("../lib/db");
const { cors, json } = require("../lib/http");

module.exports = async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET") return json(res, 405, { error: "Method not allowed" });

  try {
    const minutes = Math.min(Number(req.query.minutes) || 60, 24 * 60);
    const { rows, total } = await db.listOutflows(minutes);
    return json(res, 200, { minutes, totalBtc: total, outflows: rows });
  } catch (e) {
    console.error(e);
    return json(res, 500, { error: e.message });
  }
};
